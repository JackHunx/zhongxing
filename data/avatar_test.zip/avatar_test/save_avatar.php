<?php
define('SD_ROOT', dirname(__FILE__).'/');
@header("Expires: 0");
@header("Cache-Control: private, post-check=0, pre-check=0, max-age=0", FALSE);
@header("Pragma: no-cache");

//这里传过来会有两种类型，一先一后, big和small, 保存成功后返回一个json字串，客户端会再次post下一个.
$type = isset($_GET['type'])?trim($_GET['type']):'small';
$pic_id = trim($_GET['photoId']);
//$orgin_pic_path = $_GET['photoServer']; //原始图片地址，备用.
//$from = $_GET['from']; //原始图片地址，备用.

//生成图片存放路径
$new_avatar_path = 'avatar_'.$type.'/'.$pic_id.'_'.$type.'.jpg';

//将POST过来的二进制数据直接写入图片文件.
$len = file_put_contents(SD_ROOT.'./'.$new_avatar_path,file_get_contents("php://input"));

//原始图片比较大，压缩一下. 效果还是很明显的, 使用80%的压缩率肉眼基本没有什么区别
//小图片 不压缩约6K, 压缩后 2K, 大图片约 50K, 压缩后 10K
$avtar_img = imagecreatefromjpeg(SD_ROOT.'./'.$new_avatar_path);
imagejpeg($avtar_img,SD_ROOT.'./'.$new_avatar_path,80);
//nix系统下有必要时可以使用 chmod($filename,$permissions);

//log_result('图片大小: '.$len);


//输出新保存的图片位置, 测试时注意改一下域名路径, 后面的statusText是成功提示信息.
//status 为1 是成功上传，否则为失败.
$d = array(
	'data'=>array(
	'urls'=>array('"/avatar_test/"'.$new_avatar_path),
	),
	'status' => 1,
	'statusText'=>'长传成功',
);
$msg = json_encode($d);

echo $msg;
?>