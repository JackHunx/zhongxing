这个功能是整合网友发布的图片处理类到YII框架使用的方法。
主要步骤：下载图片处理文件类－－ThumbHandler
配置config/main.php
'import'=>array(
    ...
    'application.helpers.*',
    ...
),
将ThumbHandler.zip中的ThumbHandler.php文件放到protected/helpers下。
然后就可以在自定义类里调用该类中的方法了。
使用方法请参照ThumbHandler-test.php文件
使用方法：
<?php
require_once("ThumbHandler.php");
$t = new ThumbHandler();
$t->setSrcImg("img/test.jpg");//原图
$t->setDstImg("img/test.jpg");//生成水印后的图
$t->setMaskImg("img/test.gif");//水印内容图
$t->setMaskPosition(3);//位置1、左上，2、左下，3、右上，4、右下
$t->setMaskImgPct(100);//透明度
$t->setDstImgBorder(0,"#dddddd");//图片边框
// 指定缩放比例
$t->createImg(100,100);
/*
//示例０：
$t = new ThumbHandler();
// 基本使用
$t->setSrcImg("img/test.jpg");
$t->setMaskWord("test");
$t->setDstImgBorder(10,"#dddddd");
// 指定缩放比例
$t->createImg(50);
//示例一：
$t = new ThumbHandler();
// 基本使用
$t->setSrcImg("img/test.jpg");
$t->setMaskWord("test");
// 指定固定宽高
$t->createImg(200,200);
//示例二：
$t = new ThumbHandler();
$t->setSrcImg("img/test.jpg");
$t->setDstImg("tmp/new_test2.jpg");
$t->setMaskWord("test");
// 指定固定宽高
$t->createImg(200,200);
//示例
$t = new ThumbHandler();
$t->setSrcImg("img/test.jpg");
$t->setDstImg("tmp/new_test3.jpg");
// 指定字体文件地址
$t->setMaskFont("trebucbi.ttf");
$t->setMaskFontSize(20);
$t->setMaskFontColor("#ffff00");
$t->setMaskWord("test3333333");
$t->setDstImgBorder(99,"#dddddd");
$t->createImg(50);
//示例
$t = new ThumbHandler();
$t->setSrcImg("img/test.jpg");
$t->setDstImg("tmp/new_test4.jpg");
$t->setMaskOffsetX(55);
$t->setMaskOffsetY(55);
$t->setMaskPosition(1);
//$t->setMaskPosition(2);
//$t->setMaskPosition(3);
//$t->setMaskPosition(4);
$t->setMaskFontColor("#ffff00");
$t->setMaskWord("test");
// 指定固定宽高
$t->createImg(50);
///示例
$t = new ThumbHandler();
$t->setSrcImg("img/test.jpg");
$t->setDstImg("tmp/new_test5.jpg");
$t->setMaskFont("trebucbi.ttf");
$t->setMaskFontSize(20);
$t->setMaskFontColor("#ffffff");
$t->setMaskTxtPct(20);
$t->setDstImgBorder(10,"#dddddd");
$text = "中文";
$str = mb_convert_encoding($text, "UTF-8", "gb2312");
$t->setMaskWord($str);
$t->setMaskWord("test");
// 指定固定宽高
$t->createImg(50);
*/
?>